import Counter from "./components/counter/counter";


function App() {
  return (
    <>
      <Counter  sub={-1} add={1} double={2}/>  

    </>

  );
}

export default App;
