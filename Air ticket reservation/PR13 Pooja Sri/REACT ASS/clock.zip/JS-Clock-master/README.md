# JS-Clock
It's a CSS Clock which takes in the current time using JavaScript and upadtes the clock hands based on the current hour, minute and second.
